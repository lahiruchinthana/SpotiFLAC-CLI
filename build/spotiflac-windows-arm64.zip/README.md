# SpotiFLAC CLI

Download Spotify tracks in lossless FLAC format from Tidal, Qobuz, and Amazon Music.

## Features

- 🎵 Download from Spotify URLs (tracks, albums, playlists, artists)
- 🔄 Auto fallback across multiple services (Tidal → Amazon → Qobuz)
- 📀 Lossless FLAC quality (16-bit or 24-bit)
- � MP3 & M4A conversion with configurable bitrate (NEW in v1.2.0!)
- �🎨 Automatic metadata & cover art embedding
- 📝 Optional lyrics embedding
- 🎯 Command-line interface
- 🚀 No Spotify account required (uses web player API)
- 📋 JSON metadata output with download links

## Installation

### Download Pre-Built Binary

Download the latest release for your platform from [GitHub Releases](https://github.com/lahiruchinthana/SpotiFLAC-CLI/releases).

**Available Platforms:**

- Windows (AMD64, ARM64)
- Linux (AMD64, ARM64)
- macOS (Intel, Apple Silicon)

**No dependencies required** - just download and run!

### For Developers

If you need to build from source or modify the code, see [REQUIREMENTS.md](../REQUIREMENTS.md) in the repository root.

## Usage

### Basic Examples

```bash
# Single track
spotiflac https://open.spotify.com/track/...

# Album
spotiflac https://open.spotify.com/album/...

# Playlist
spotiflac https://open.spotify.com/playlist/...

# Artist discography
spotiflac https://open.spotify.com/artist/...
```

### Service Selection

```bash
# Auto mode (tries multiple services)
spotiflac URL --auto

# Specific service
spotiflac URL --service tidal
spotiflac URL --service qobuz
spotiflac URL --service amazon

# Custom service order
spotiflac URL --auto --auto-order qobuz-tidal-amazon
```

### Quality Options

```bash
# Tidal qualities
spotiflac URL --service tidal --quality LOSSLESS      # 16-bit FLAC
spotiflac URL --service tidal --quality HI_RES        # 24-bit FLAC

# Qobuz qualities
spotiflac URL --service qobuz --quality 6   # 16-bit FLAC
spotiflac URL --service qobuz --quality 7   # 24-bit FLAC
spotiflac URL --service qobuz --quality 27  # Hi-Res 24-bit

# Auto mode quality
spotiflac URL --auto --auto-quality 16  # Prefer 16-bit
spotiflac URL --auto --auto-quality 24  # Prefer 24-bit
```

### Output Options

```bash
# Custom output directory
spotiflac URL --output ~/Music/Downloads

# Output format (NEW in v1.2.0!)
spotiflac URL --output-format mp3              # Convert to MP3
spotiflac URL --output-format mp3 --mp3-bitrate 320k  # MP3 @ 320kbps
spotiflac URL --output-format m4a              # Convert to M4A

# Filename formats
spotiflac URL --filename-format title-artist  # "Perfect - Ed Sheeran.flac"
spotiflac URL --filename-format artist-title  # "Ed Sheeran - Perfect.flac"
spotiflac URL --filename-format title         # "Perfect.flac"

# Include track numbers
spotiflac URL --track-number  # "01 - Perfect - Ed Sheeran.flac"

# Custom template
spotiflac URL --filename-format "{artist} - {title} [{album}]"
```

### Metadata Options

```bash
# Embed lyrics
spotiflac URL --embed-lyrics

# Maximum quality cover art
spotiflac URL --max-quality-cover

# Both
spotiflac URL --embed-lyrics --max-quality-cover
```

### Batch Downloads

```bash
# Album with delay between tracks
spotiflac ALBUM_URL --delay 2.0

# Playlist without delay
spotiflac PLAYLIST_URL --delay 0

# Custom region for matching
spotiflac URL --region US
spotiflac URL --region GB
```

### Output Control

```bash
# Quiet mode (minimal output)
spotiflac URL --quiet

# Verbose mode (debug info)
spotiflac URL --verbose

# Normal mode (default)
spotiflac URL
```

### Metadata Export

```bash
# Get metadata as JSON without downloading
spotiflac URL --dump-json
spotiflac URL -j

# Save metadata to .info.json file while downloading
spotiflac URL --write-info-json

# Pipe to jq for filtering
spotiflac URL -j | jq '.metadata.track.name'
spotiflac URL -j | jq '.download_links.tidal.url'
```

**JSON Output includes:**

- Track metadata (name, artist, album, ISRC, duration, etc.)
- Direct download links (Tidal, Amazon, Qobuz URLs)
- Available services list
- Ready-to-use CLI commands for each service

## Command Reference

### Flags

| Flag                  | Short | Type   | Default              | Description                         |
| --------------------- | ----- | ------ | -------------------- | ----------------------------------- |
| `--output`            | `-o`  | string | `.`                  | Output directory                    |
| `--service`           | `-s`  | string | `auto`               | Service: tidal, qobuz, amazon, auto |
| `--auto`              | `-a`  | bool   | false                | Auto mode (same as --service auto)  |
| `--auto-order`        |       | string | `tidal-amazon-qobuz` | Service order for auto mode         |
| `--auto-quality`      |       | string | `24`                 | Auto quality: 16 or 24 bit          |
| `--quality`           | `-q`  | string |                      | Quality preset (service-specific)   |
| `--format`            |       | string |                      | Audio format (alias for quality)    |
| `--fallback`          |       | bool   | true                 | Allow fallback to lower quality     |
| `--filename-format`   | `-f`  | string | `title-artist`       | Filename template                   |
| `--track-number`      | `-n`  | bool   | false                | Include track number in filename    |
| `--embed-lyrics`      | `-l`  | bool   | false                | Embed lyrics                        |
| `--max-quality-cover` | `-c`  | bool   | false                | Embed max quality cover             |
| `--delay`             | `-d`  | float  | `1.0`                | Delay between downloads (seconds)   |
| `--region`            | `-r`  | string | `US`                 | Region code for matching            |
| `--quiet`             |       | bool   | false                | Quiet mode                          |
| `--verbose`           | `-v`  | bool   | false                | Verbose output                      |
| `--dump-json`         | `-j`  | bool   | false                | Print metadata as JSON and exit     |
| `--write-info-json`   |       | bool   | false                | Write metadata to .info.json file   |
| `--help`              | `-h`  |        |                      | Show help                           |
| `--version`           |       |        |                      | Show version                        |

### Filename Template Variables

- `{title}` - Track title
- `{artist}` - Track artist(s)
- `{album}` - Album name
- `{album_artist}` - Album artist
- `{track_number}` - Track number (padded)
- `{disc_number}` - Disc number
- `{year}` - Release year
- `{isrc}` - ISRC code

## Service-Specific Notes

### Tidal

- Best coverage for mainstream music
- Supports up to 24-bit / 192kHz (HI_RES_LOSSLESS)
- Default quality: LOSSLESS (16-bit / 44.1kHz)
- No authentication required (uses session.json if available)

### Qobuz

- Excellent classical and jazz catalog
- Supports up to 24-bit / 192kHz (quality 27)
- Quality codes: 6 (16-bit), 7 (24-bit), 27 (Hi-Res 24-bit)
- Requires Deezer ISRC lookup for matching

### Amazon Music

- Good coverage for popular music
- Quality levels vary by track
- Automatic quality selection
- Regional availability may vary

## Troubleshooting

### "Failed to fetch metadata"

- Check if Spotify URL is valid and accessible
- Some regional content may not be available
- Try different region code: `--region GB` or `--region DE`

### "Download failed: track not found"

- Not all Spotify tracks are available on other services
- Try different service: `--service tidal` or `--service qobuz`
- Use auto mode: `--auto` to try multiple services

### "FFmpeg not found"

- Install FFmpeg and ensure it's in your PATH
- Windows: Add FFmpeg bin folder to System Environment Variables
- Linux/macOS: Install via package manager

### "Quality not available, trying fallback"

- Requested quality not available for this track
- Fallback automatically tries lower quality
- Disable fallback: `--fallback=false` to fail instead

## Advanced Examples

### Get Metadata Only (No Download)

```bash
# Get JSON metadata
spotiflac https://open.spotify.com/track/... -j

# Get specific field with jq
spotiflac URL -j | jq '.metadata.track.name'
spotiflac URL -j | jq '.download_links.tidal.url'
spotiflac URL -j | jq '.available_services'

# Save metadata for later
spotiflac URL -j > track_info.json
```

### Complete Album Download

```bash
spotiflac https://open.spotify.com/album/... \
  --auto \
  --auto-quality 24 \
  --output ~/Music/Albums \
  --filename-format "{track_number} - {artist} - {title}" \
  --embed-lyrics \
  --max-quality-cover \
  --verbose
```

### Batch Playlist with Delay

```bash
spotiflac https://open.spotify.com/playlist/... \
  --service tidal \
  --quality HI_RES \
  --output ./Playlists \
  --delay 3.0 \
  --track-number
```

### Quick Single Track

```bash
spotiflac URL -a -o ./Downloads
```

### High Quality with Fallback Chain

```bash
spotiflac URL \
  --auto \
  --auto-order qobuz-tidal-amazon \
  --auto-quality 24 \
  --fallback
```

## Differences from GUI Version

### Removed

- Web interface
- Real-time progress visualization
- Search and browse features
- Wails framework

### Kept

- All download functionality
- Service integration (Tidal, Qobuz, Amazon)
- Spotify metadata fetching
- FFmpeg audio processing
- Metadata embedding
- Lyrics fetching
- History database

### Added

- Cobra CLI framework
- Command-line argument parsing
- Batch processing with progress
- Auto-fallback mode
- Command-line interface

## Building

### Dependencies

```go
// go_cli.mod
require (
    github.com/spf13/cobra v1.8.1
    github.com/lib/pq v1.10.9
    github.com/mattn/go-sqlite3 v1.14.24
)
```

### Development

```bash
# Run without building
go run main_cli.go URL --auto

# Build with debug info
go build -o spotiflac main_cli.go

# Build optimized binary
go build -ldflags="-s -w" -o spotiflac main_cli.go
```

## License

Same as SpotiFLAC GUI - Check LICENSE file

## Credits

CLI version built on top of SpotiFLAC 7.0.7 by converting the Wails GUI application to a command-line tool.

- Original SpotiFLAC: [GitHub](https://github.com/yourusername/spotiflac)
- Cobra CLI: [GitHub](https://github.com/spf13/cobra)

## Support

For issues or questions:

1. Check this README for solutions
2. Review the troubleshooting section
3. Check original SpotiFLAC documentation
4. Open an issue on GitHub
